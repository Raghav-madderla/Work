$(document).ready(function(){

    $("#name-id").change(function(){
        nameCheck();
    });
    $("#email-id").change(function(){
        emailCheck();
    });
    $("#org-id").change(function(){
        orgNameCheck();
    });
    $("#submit-button").click(function(){
        submitButton();
    });
    $("#clear-form").click(function(){
        clearForm();
    });

    $("#radio-male").click(function(){
        alert("Hello Sir!");
    });

    $("#radio-female").click(function(){
        alert("Hello Lady!");
    });

    $("#state-select").change(function(){
        $("#promocode").val($("#state-select").val()+"-PROMO");
    });

    function checkEmailFormat(textInput){
        var mailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        return textInput.match(mailFormat);
    }

    function nameCheck(){
        if($("#name-id").val()===""){
            $("#required-alert-name").html("Name is required");
            validationAlert();
        }else{
            $("#required-alert-name").html("*");
            validationAlert();
        }
    }

    function emailCheck(){
        let email = $("#email-id").val();
        if(email===""){
            $("#required-alert-email").html("Email is requied");
            validationAlert();
        }else{
            if(checkEmailFormat(email)) $("#required-alert-email").html("*");
            else $("#required-alert-email").html("Email is invalid");
            validationAlert();
        }
    }

    function orgNameCheck(){
        if($("#org-id").val()===""){
            $("#required-alert-orgname").html("Organzation Name is required");
            validationAlert();
        }else{
            $("#required-alert-orgname").html("*");
            validationAlert();
        }
    }

    function validationAlert(){
        if(isEmpty("#required-alert-name") && isEmpty("#required-alert-email") && isEmpty("#required-alert-orgname")){
            $("#required-message").html("");
        }else{
            $("#required-message").html("Please fill the required fields below");
        }
    }

    function isEmpty(elementId){
        let elementValue = $(elementId).html();
        return elementValue === "*";
    }

    function submitButton(){
        nameCheck();
        emailCheck();
        orgNameCheck();
        validationAlert();
        if($("#required-message").html()===""){
            alert("Sucessfully Submitted!");
            clearForm();
        }
    }

    function clearForm(){
        $(".reset-by-value").val("");
        $(".reset-by-html").html("*");
        $("#required-message").html("");
        $("[type=radio").prop("checked", false);
    }

});

