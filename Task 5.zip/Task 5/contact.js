function checkEmailFormat(textInput){
    var mailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return textInput.match(mailFormat);
}

function greetingAlert(){
    if(document.getElementById('radio-male').checked){
        alert('Hello Sir!');
    }else if(document.getElementById('radio-female').checked){
        alert('Hello Lady!');
    }
}
function isEmpty(elementId){
    let elementValue = document.getElementById(elementId).innerHTML;
    return elementValue === "";
}

function validationAlert(){
    if(isEmpty('required-alert-name') && isEmpty('required-alert-email') && isEmpty('required-alert-orgname')){
        document.getElementById('required-message').innerHTML="";
    }else{
        document.getElementById('required-message').innerHTML="Please fill the required fields below";
    }
}

function nameCheck(){
    let nameValue =document.getElementById('name-id').value;
    if(nameValue==="") {
        document.getElementById('required-alert-name').innerHTML="Name is required";
        validationAlert();
    }
    else {
        document.getElementById('required-alert-name').innerHTML="";
        validationAlert();
    }
}

function emailCheck(){
    let emailValue = document.getElementById('email-id').value;
    if(emailValue===""){
        document.getElementById('required-alert-email').innerHTML="Email is required";
        validationAlert();
    }
    else{
        if(checkEmailFormat(emailValue)) document.getElementById('required-alert-email').innerHTML="";
        else document.getElementById('required-alert-email').innerHTML="Email invalid";
        validationAlert();
    }
}

function orgNameCheck(){
    let orgNameValue = document.getElementById('org-id').value;
    if(orgNameValue==="") {
        document.getElementById('required-alert-orgname').innerHTML="Organzation Name is required";
        validationAlert();
    }
    else{
        document.getElementById('required-alert-orgname').innerHTML="";
        validationAlert();
    } 
}

function addPromo(){
    let state = document.getElementById("state-select").value;
    let codeExtender ='-PROMO';
    document.getElementById('promocode').value=state+codeExtender;
}

function submitButton(){
    nameCheck();
    emailCheck();
    orgNameCheck();
    validationAlert();
    if(isEmpty('required-message')) {
        alert("Submitted Successfully!");
        clearForm();
    }
}

function clearForm(){
    document.getElementById('name-id') .value= "";
    document.getElementById('email-id') .value= "";
    document.getElementById('telephone') .value= "";
    document.getElementById('org-id') .value= "";
    document.getElementById('city') .value= "";
    document.getElementById('state-select') .value= "";
    document.getElementById('promocode') .value= "";
    document.getElementById('website') .value= "";
    document.getElementById('comment-one') .value= "";
    document.getElementById('comment-two') .value= "";
    document.getElementById('required-alert-name').innerHTML="";
    document.getElementById('required-alert-email').innerHTML="";
    document.getElementById('required-alert-orgname').innerHTML="";
    document.getElementById('required-message').innerHTML="";
    var radList = document.getElementsByName('radio-output');
    for (var i = 0; i < radList.length; i++) {
      if(radList[i].checked) radList[i].checked = false;
    }
    var radGender = document.getElementsByName('gender-radio-output');
    for (var i = 0; i < radGender.length; i++) {
        if(radGender[i].checked) radGender[i].checked = false;
    }
}
