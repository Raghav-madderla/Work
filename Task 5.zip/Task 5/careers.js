const readFile = document.getElementById("read-file");
const BrowseBtn = document.getElementById("upload-button");
const fileText = document.getElementById("file-text");

BrowseBtn.addEventListener("click", function() {
    readFile.click();
});

readFile.addEventListener("change",  function(){
    if(readFile.value) fileText.value = readFile.value;
});

function checkEmailFormat(textInput){
    var mailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return textInput.match(mailFormat);
}

function emailCheck(){
    let emailValue = document.getElementById('email-id').value;
    if(emailValue===""){
        document.getElementById('required-alert-email').innerHTML=" Email is required";
    }
    else{
        if(checkEmailFormat(emailValue)) document.getElementById('required-alert-email').innerHTML="";
        else document.getElementById('required-alert-email').innerHTML=" Email invalid";
    }
}

function submitIt(){
    if(document.getElementById('email-id').value==="") emailCheck();
    else alert("Submitted Successfully!");
}